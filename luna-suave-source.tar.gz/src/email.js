class ResendMailer {
  constructor(config) { this.config = config; }
  get enabled() { return Boolean(this.config.resendApiKey && this.config.from); }
  async sendPurchaseConfirmation({ user, order }) {
    if (!this.enabled) return { status: 'not_configured' };
    const html = `<h1>Gracias por tu compra, ${user.name}</h1><p>Recibimos tu pedido <strong>${order.number}</strong> por $${order.total.toLocaleString('es-CO')} COP.</p><p>Estado: ${order.status}. Guía: ${order.shipment?.trackingNumber || 'pendiente'}.</p>`;
    const response = await fetch('https://api.resend.com/emails', { method: 'POST', headers: { authorization: `Bearer ${this.config.resendApiKey}`, 'content-type': 'application/json' }, body: JSON.stringify({ from: this.config.from, to: [user.email], subject: `Confirmación de compra ${order.number}`, html }) });
    if (!response.ok) throw new Error('No fue posible enviar el correo transaccional');
    return { status: 'sent', ...(await response.json()) };
  }
}
function mailer(config) { return new ResendMailer(config.email); }
module.exports = { mailer };
