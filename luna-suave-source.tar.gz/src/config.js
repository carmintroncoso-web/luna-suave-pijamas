const path = require('node:path');

function loadEnv() {
  // Lee .env sólo si existe, sin sobreescribir variables del sistema.
  const fs = require('node:fs');
  const envPath = path.join(process.cwd(), '.env');
  if (!fs.existsSync(envPath)) return;
  for (const line of fs.readFileSync(envPath, 'utf8').split(/\r?\n/)) {
    const match = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*)\s*$/);
    if (match && process.env[match[1]] === undefined) process.env[match[1]] = match[2].replace(/^['"]|['"]$/g, '');
  }
}

loadEnv();

module.exports = {
  port: Number(process.env.PORT || 3000),
  tokenSecret: process.env.JWT_SECRET || 'development-only-change-me',
  databaseFile: process.env.DATABASE_FILE || path.join(process.cwd(), 'data', 'store.json'),
  publicBaseUrl: (process.env.PUBLIC_BASE_URL || `http://localhost:${process.env.PORT || 3000}`).replace(/\/$/, ''),
  admin: { email: process.env.ADMIN_EMAIL, password: process.env.ADMIN_PASSWORD },
  shippingProvider: process.env.SHIPPING_PROVIDER || 'auto',
  coordinadora: { quoteUrl: process.env.COORDINADORA_QUOTE_URL, shipmentUrl: process.env.COORDINADORA_SHIPMENT_URL, apiKey: process.env.COORDINADORA_API_KEY },
  envia: { quoteUrl: process.env.ENVIA_QUOTE_URL, shipmentUrl: process.env.ENVIA_SHIPMENT_URL, apiKey: process.env.ENVIA_API_KEY },
  servientrega: { quoteUrl: process.env.SERVIENTREGA_QUOTE_URL, shipmentUrl: process.env.SERVIENTREGA_SHIPMENT_URL, apiKey: process.env.SERVIENTREGA_API_KEY },
  interrapidisimo: { quoteUrl: process.env.INTERAPIDISIMO_QUOTE_URL, shipmentUrl: process.env.INTERAPIDISIMO_SHIPMENT_URL, apiKey: process.env.INTERAPIDISIMO_API_KEY },
  wompi: { publicKey: process.env.WOMPI_PUBLIC_KEY, integritySecret: process.env.WOMPI_INTEGRITY_SECRET },
  email: { resendApiKey: process.env.RESEND_API_KEY, from: process.env.EMAIL_FROM }
};
