const crypto = require('node:crypto');

class WompiGateway {
  constructor(config, publicBaseUrl) { this.config = config; this.publicBaseUrl = publicBaseUrl; }
  get enabled() { return Boolean(this.config.publicKey && this.config.integritySecret); }
  createCheckout(order) {
    if (!this.enabled) return { provider: 'wompi', status: 'configuration_required', message: 'El pago en línea estará disponible cuando la tienda configure Wompi.' };
    const amountInCents = order.total * 100;
    const integrity = crypto.createHash('sha256').update(`${order.number}${amountInCents}COP${this.config.integritySecret}`).digest('hex');
    return { provider: 'wompi', status: 'awaiting_payment', endpoint: 'https://checkout.wompi.co/p/', fields: { 'public-key': this.config.publicKey, currency: 'COP', 'amount-in-cents': String(amountInCents), reference: order.number, 'redirect-url': `${this.publicBaseUrl}/?payment=return&order=${encodeURIComponent(order.id)}`, 'signature:integrity': integrity } };
  }
}
function paymentService(config) { const wompi = new WompiGateway(config.wompi, config.publicBaseUrl); return { createCheckout: (order) => wompi.createCheckout(order), status: () => ({ wompi: wompi.enabled }) }; }
module.exports = { paymentService };
