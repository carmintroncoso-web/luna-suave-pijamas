const { id } = require('./lib');

class LocalShippingAdapter {
  constructor() { this.name = 'local'; }
  async quote({ destination, items }) {
    const units = items.reduce((sum, item) => sum + item.quantity, 0);
    const remote = /amazonas|san andr/i.test(destination.department || '');
    return { provider: this.name, amount: remote ? 24000 + units * 2500 : 12000 + units * 1500, currency: 'COP', estimatedDays: remote ? 7 : 3 };
  }
  async createShipment({ order, quote }) { return { provider: this.name, trackingNumber: `LOC-${id('trk').slice(-8).toUpperCase()}`, status: 'created', amount: quote.amount, orderId: order.id }; }
}

class RemoteShippingAdapter extends LocalShippingAdapter {
  constructor(name, config) { super(); this.name = name; this.config = config; }
  get enabled() { return Boolean(this.config.quoteUrl && this.config.shipmentUrl && this.config.apiKey); }
  async request(url, payload) {
    const response = await fetch(url, { method: 'POST', headers: { 'content-type': 'application/json', 'x-api-key': this.config.apiKey, authorization: `Bearer ${this.config.apiKey}` }, body: JSON.stringify(payload), signal: AbortSignal.timeout(8000) });
    if (!response.ok) throw new Error(`${this.name} no pudo procesar la solicitud`);
    return response.json();
  }
  async quote(payload) {
    if (!this.enabled) return super.quote(payload);
    try {
      const data = await this.request(this.config.quoteUrl, payload);
      const amount = Number(data.amount ?? data.total ?? data.price);
      if (!Number.isFinite(amount) || amount < 0) throw new Error('Cotización inválida');
      return { provider: this.name, amount, currency: data.currency || 'COP', estimatedDays: Number(data.estimatedDays ?? data.deliveryDays ?? 3), externalQuoteId: data.id || data.quoteId };
    } catch (error) { return { ...(await super.quote(payload)), fallbackReason: error.message }; }
  }
  async createShipment(payload) {
    if (!this.enabled) return super.createShipment(payload);
    try {
      const data = await this.request(this.config.shipmentUrl, payload);
      return { provider: this.name, trackingNumber: data.trackingNumber || data.guide || data.number, status: data.status || 'created', amount: payload.quote.amount, externalShipmentId: data.id };
    } catch (error) { return { ...(await super.createShipment(payload)), fallbackReason: error.message }; }
  }
}

function shippingService(config) {
  const local = new LocalShippingAdapter();
  const adapters = { coordinadora: new RemoteShippingAdapter('coordinadora', config.coordinadora), envia: new RemoteShippingAdapter('envia', config.envia), servientrega: new RemoteShippingAdapter('servientrega', config.servientrega), interrapidisimo: new RemoteShippingAdapter('interrapidisimo', config.interrapidisimo), local };
  function resolve(requested) {
    const choice = requested || config.shippingProvider;
    if (choice && choice !== 'auto' && adapters[choice]) return adapters[choice].enabled ? adapters[choice] : local;
    return Object.values(adapters).find(a => a.enabled) || local;
  }
  return { quote: (data) => resolve(data.provider).quote(data), createShipment: (data) => resolve(data.provider).createShipment(data), providers: () => Object.keys(adapters) };
}
module.exports = { shippingService };
