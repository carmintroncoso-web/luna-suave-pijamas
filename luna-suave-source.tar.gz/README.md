# Pijamas Colombia API

Tienda web de pijamas con catálogo por talla, cuentas, carrito, checkout, historial de pedidos, panel administrativo, contabilidad y logística. Los precios están expresados como enteros en pesos colombianos (COP).

## Ejecutar

Requiere Node.js 20 o posterior.

```powershell
Copy-Item .env.example .env
node src/server.js
```

La aplicación queda disponible en `http://localhost:3000`. Comprueba con `GET /health` y descarga el contrato OpenAPI en `GET /openapi.yaml` (o `/api/docs`). Al primer arranque se crea `data/store.json` con productos y FAQ. Para volver a los datos de muestra, detén el servidor y borra sólo `data/store.json`.

## Acceso de superusuario

Antes del primer arranque define `ADMIN_EMAIL` y `ADMIN_PASSWORD` en variables de entorno. Así se crea la única cuenta inicial con rol de administradora, sin publicar una contraseña por defecto. La contraseña se guarda con PBKDF2 y el token firmado vence en siete días.

## Flujo principal

1. Crea una cuenta con `POST /api/auth/register`, o inicia sesión en `/api/auth/login`.
2. En los endpoints privados agrega `Authorization: Bearer TU_TOKEN`.
3. Consulta `GET /api/products`, añade variantes con `POST /api/cart/items` y finaliza en `POST /api/checkout`.
4. La administración gestiona catálogo (incluye URL de imagen, precios, costos, tallas e inventario), pedidos y el resumen contable.

Ejemplo breve de registro:

```powershell
Invoke-RestMethod -Method Post http://localhost:3000/api/auth/register -ContentType 'application/json' -Body '{"name":"Laura","email":"laura@example.com","password":"ClaveSegura1"}'
```

## Endpoints

| Área | Rutas |
| --- | --- |
| Cuenta | `POST /api/auth/register`, `POST /api/auth/login` |
| Catálogo | `GET/POST /api/products`, `GET/PATCH /api/products/{id-o-slug}` |
| Carrito | `GET /api/cart`, `POST /api/cart/items`, `PATCH/DELETE /api/cart/items/{variantId}` |
| Logística | `POST /api/shipping/quote`, `POST /api/checkout` |
| Pedidos/ventas | `GET /api/orders`, `PATCH /api/orders/{id}`, `GET /api/admin/sales?group=day|week|month|year`, `GET /api/admin/accounting` |
| Pagos | `GET /api/payments/config`, checkout Wompi cuando esté configurado |
| Ayuda | `GET /api/faqs`, `POST /api/chat` |

Los errores de validación devuelven HTTP 422 y el cuerpo `{ "error": { "message": "..." } }`.

## Envíos y seguridad

`src/shipping.js` integra adaptadores para **Coordinadora**, **Envia**, **Servientrega** e **Interrapidísimo**. Sin credenciales, el checkout usa el cálculo local marcado como fallback y genera una guía local: no se presenta como una guía real del courier. Para habilitar cada conexión se necesitan su contrato, llave y endpoints de cotización/despacho (`*_QUOTE_URL`, `*_SHIPMENT_URL`, `*_API_KEY`).

El pago en línea está preparado para **Wompi**. Define `WOMPI_PUBLIC_KEY`, `WOMPI_INTEGRITY_SECRET` y `PUBLIC_BASE_URL`; el comprador será redirigido al checkout de Wompi. El correo de confirmación se activa al definir una clave de **Resend** y un remitente verificado (`RESEND_API_KEY`, `EMAIL_FROM`). Ninguna clave se almacena en GitHub.

Antes de producción, valida cada payload con la documentación contractual vigente de la transportadora, añade una base de datos transaccional y limita CORS a los dominios del frontend.

## Publicar gratis en Render

El archivo `render.yaml` prepara una instancia web gratuita. Después de subir este proyecto a GitHub, entra a [Render](https://render.com/), conecta tu cuenta de GitHub y crea un **Blueprint** desde el repositorio. Render leerá el archivo, generará un secreto seguro para los tokens y publicará una dirección `https://…onrender.com` con HTTPS.

El plan gratuito se suspende tras 15 minutos sin tráfico y tarda aproximadamente un minuto en despertar. Su disco es temporal: usuarios, carritos y pedidos creados en la tienda se reinician al redesplegar o reiniciar el servicio. Es adecuado como demostración pública. Para una operación comercial persistente, conecta una base de datos gestionada antes de recibir pedidos reales.
