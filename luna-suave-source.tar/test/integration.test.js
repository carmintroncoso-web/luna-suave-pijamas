const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

process.env.PORT = '3199';
process.env.DATABASE_FILE = path.join(process.cwd(), 'work', 'test-store.json');
fs.rmSync(process.env.DATABASE_FILE, { force: true });
const { server } = require('../src/server');
const base = 'http://localhost:3199';

test('registro, carrito y checkout reducen inventario', async (t) => {
  t.after(() => { server.close(); fs.rmSync(process.env.DATABASE_FILE, { force: true }); });
  const email = `test-${Date.now()}@example.com`;
  const registered = await fetch(`${base}/api/auth/register`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ name: 'Cliente Test', email, password: 'ClaveSegura1' }) });
  assert.equal(registered.status, 201);
  const { token } = await registered.json();
  const headers = { authorization: `Bearer ${token}`, 'content-type': 'application/json' };
  const add = await fetch(`${base}/api/cart/items`, { method: 'POST', headers, body: JSON.stringify({ variantId: 'var_luna_s', quantity: 1 }) });
  assert.equal(add.status, 200);
  const checkout = await fetch(`${base}/api/checkout`, { method: 'POST', headers, body: JSON.stringify({ shippingAddress: { city: 'Bogotá', department: 'Cundinamarca', address: 'Calle 1 # 2-3' }, paymentMethod: 'cash_on_delivery' }) });
  assert.equal(checkout.status, 201);
  const result = await checkout.json();
  assert.equal(result.data.shipment.provider, 'local');
  assert.equal(result.data.total, 103400);
});
