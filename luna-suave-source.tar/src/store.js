const fs = require('node:fs');
const path = require('node:path');
const { id, now, hashPassword } = require('./lib');

const seed = () => ({
  users: [{ id: 'usr_admin', name: 'Administradora', email: 'admin@pijamas.co', passwordHash: hashPassword('Admin123!'), role: 'admin', createdAt: now() }],
  products: [
    { id: 'prd_luna', name: 'Pijama Luna Algodón', slug: 'pijama-luna-algodon', description: 'Conjunto suave de algodón colombiano.', category: 'Mujer', active: true, createdAt: now(), variants: [
      { id: 'var_luna_s', size: 'S', color: 'Rosa', sku: 'LUNA-ROS-S', price: 89900, inventory: 12 },
      { id: 'var_luna_m', size: 'M', color: 'Rosa', sku: 'LUNA-ROS-M', price: 89900, inventory: 8 },
      { id: 'var_luna_l', size: 'L', color: 'Azul', sku: 'LUNA-AZU-L', price: 94900, inventory: 5 }
    ] },
    { id: 'prd_nube', name: 'Pijama Nube Infantil', slug: 'pijama-nube-infantil', description: 'Pijama infantil estampada.', category: 'Niños', active: true, createdAt: now(), variants: [
      { id: 'var_nube_6', size: '6', color: 'Lila', sku: 'NUBE-LIL-6', price: 62900, inventory: 10 },
      { id: 'var_nube_8', size: '8', color: 'Lila', sku: 'NUBE-LIL-8', price: 62900, inventory: 7 }
    ] }
  ],
  carts: [], orders: [], faqs: [
    { id: 'faq_envio', question: '¿Cuánto tarda el envío?', answer: 'En ciudades principales suele tardar entre 2 y 5 días hábiles.' },
    { id: 'faq_cambios', question: '¿Puedo cambiar la talla?', answer: 'Sí. Escríbenos dentro de los 30 días posteriores a la compra, con la prenda sin uso.' },
    { id: 'faq_pagos', question: '¿Qué medios de pago aceptan?', answer: 'Esta API permite registrar pagos contra entrega, transferencia y pago en línea.' }
  ]
});

class Store {
  constructor(file) { this.file = file; this.data = null; }
  load() {
    if (this.data) return this.data;
    fs.mkdirSync(path.dirname(this.file), { recursive: true });
    this.data = fs.existsSync(this.file) ? JSON.parse(fs.readFileSync(this.file, 'utf8')) : seed();
    if (!fs.existsSync(this.file)) this.save();
    return this.data;
  }
  save() { fs.writeFileSync(this.file, JSON.stringify(this.load(), null, 2)); }
  nextId(prefix) { return id(prefix); }
}
module.exports = { Store };
