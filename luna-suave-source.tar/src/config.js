const path = require('node:path');

function loadEnv() {
  // Lee .env sólo si existe, sin sobreescribir variables del sistema.
  const fs = require('node:fs');
  const envPath = path.join(process.cwd(), '.env');
  if (!fs.existsSync(envPath)) return;
  for (const line of fs.readFileSync(envPath, 'utf8').split(/\r?\n/)) {
    const match = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*)\s*$/);
    if (match && process.env[match[1]] === undefined) process.env[match[1]] = match[2].replace(/^['"]|['"]$/g, '');
  }
}

loadEnv();

module.exports = {
  port: Number(process.env.PORT || 3000),
  tokenSecret: process.env.JWT_SECRET || 'development-only-change-me',
  databaseFile: process.env.DATABASE_FILE || path.join(process.cwd(), 'data', 'store.json'),
  shippingProvider: process.env.SHIPPING_PROVIDER || 'auto',
  coordinadora: { url: process.env.COORDINADORA_API_URL, apiKey: process.env.COORDINADORA_API_KEY },
  envia: { url: process.env.ENVIA_API_URL, apiKey: process.env.ENVIA_API_KEY }
};
