const { id } = require('./lib');

class LocalShippingAdapter {
  constructor() { this.name = 'local'; }
  async quote({ destination, items }) {
    const units = items.reduce((sum, item) => sum + item.quantity, 0);
    const remote = /amazonas|san andr/i.test(destination.department || '');
    return { provider: this.name, amount: remote ? 24000 + units * 2500 : 12000 + units * 1500, currency: 'COP', estimatedDays: remote ? 7 : 3 };
  }
  async createShipment({ order, quote }) { return { provider: this.name, trackingNumber: `LOC-${id('trk').slice(-8).toUpperCase()}`, status: 'created', amount: quote.amount, orderId: order.id }; }
}

class RemoteShippingAdapter extends LocalShippingAdapter {
  constructor(name, config) { super(); this.name = name; this.config = config; }
  get enabled() { return Boolean(this.config.url && this.config.apiKey); }
  // Punto de integración: sustituye esta simulación por la llamada HTTP documentada del transportador.
  // Las credenciales viven exclusivamente en variables de entorno y nunca en respuestas de API.
  async quote(payload) { const quote = await super.quote(payload); return { ...quote, provider: this.enabled ? this.name : 'local', simulated: !this.enabled }; }
  async createShipment(payload) { const shipment = await super.createShipment(payload); return { ...shipment, provider: this.enabled ? this.name : 'local', simulated: !this.enabled }; }
}

function shippingService(config) {
  const local = new LocalShippingAdapter();
  const adapters = { coordinadora: new RemoteShippingAdapter('coordinadora', config.coordinadora), envia: new RemoteShippingAdapter('envia', config.envia), local };
  function resolve(requested) {
    const choice = requested || config.shippingProvider;
    if (choice && choice !== 'auto' && adapters[choice]) return adapters[choice].enabled ? adapters[choice] : local;
    return Object.values(adapters).find(a => a.enabled) || local;
  }
  return { quote: (data) => resolve(data.provider).quote(data), createShipment: (data) => resolve(data.provider).createShipment(data), providers: () => Object.keys(adapters) };
}
module.exports = { shippingService };
